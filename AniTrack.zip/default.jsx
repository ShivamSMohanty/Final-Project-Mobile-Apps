import React, { useState } from "react";
import {View,Text,TouchableOpacity,StyleSheet,ScrollView,SafeAreaView,AppRegistry} from "react-native";
export default function App() {
  const animeData = [
      
/* These are just example animes that should change. Users will later on choose what show they are watching from a list of animes hopefully. */

    {
      id: 1,
      title: "Demon Slayer",
      genre: "Action",
      episodes: 26,
      rating: 8.9,
      year: 2019,
    },
    {
      id: 2,
      title: "Attack on Titan",
      genre: "Action",
      episodes: 25,
      rating: 9.1,
      year: 2023,
    },
    {
      id: 3,
      title: "Jujutsu Kaisen",
      genre: "Fantasy",
      episodes: 24,
      rating: 8.7,
      year: 2020,
    },
    {
      id: 4,
      title: "Death Note",
      genre: "Mystery",
      episodes: 37,
      rating: 9.0,
      year: 2006,
    },
  ];

  const [screen, setScreen] = useState("Home");
  const [selectedAnime, setSelectedAnime] = useState(null);
  const [watchlist, setWatchlist] = useState([
    {
      id: 2,
      title: "Attack on Titan",
      genre: "Action",
      episodes: 25,
      progress: 12,
      status: "Watching",
      userRating: 4,
    },
  ]);

  function addToWatchlist(anime) {
    const exists = watchlist.some((item) => item.id === anime.id);
    if (!exists) {
      setWatchlist([
        ...watchlist,
        {
          ...anime,
          progress: 0,
          status: "Watching",
          userRating: 0,
        },
      ]);
    }
    setSelectedAnime(null);
    setScreen("List");
  }
  function updateProgress(id, amount) {
    setWatchlist(
      watchlist.map((item) =>
        item.id === id
          ? {
              ...item,
              progress: Math.max(
                0,
                Math.min(item.episodes, item.progress + amount)
              ),
            }
          : item
      )
    );
  }
  function updateStatus(id, status) {
    setWatchlist(
      watchlist.map((item) =>
        item.id === id
          ? {
              ...item,
              status: status,
              progress: status === "Completed" ? item.episodes : item.progress,
            }
          : item
      )
    );
  }
  function updateRating(id, rating) {
    setWatchlist(
      watchlist.map((item) =>
        item.id === id ? { ...item, userRating: rating } : item
      )
    );
  }
  const totalEpisodes = watchlist.reduce((sum, item) => sum + item.progress, 0);
  const totalHours = Math.round(totalEpisodes * 0.4);
  const completed = watchlist.filter((item) => item.status === "Completed");

  function getGenreCount(genre) {
    return watchlist.filter((item) => item.genre === genre).length;
  }

  function HomeScreen() {
    return (
      <ScrollView style={styles.content}>
        <Text style={styles.header}>Home</Text>

        <View style={styles.profileRow}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>A</Text>
          </View>
          <View>
            <Text style={styles.title}>Hey, User!</Text>
            <Text style={styles.subText}>3 new recommendations</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Continue Watching</Text>
        {watchlist
          .filter((item) => item.status === "Watching")
          .map((item) => (
            <View key={item.id} style={styles.card}>
              <View style={styles.poster} />
              <View style={{ flex: 1 }}>
                <Text style={styles.cardTitle}>{item.title}</Text>
                <Text style={styles.subText}>
                  Ep {item.progress} / {item.episodes}
                </Text>
                <View style={styles.progressBar}>
                  <View
                    style={[
                      styles.progressFill,
                      { width: `${(item.progress / item.episodes) * 100}%` },
                    ]}
                  />
                </View>
              </View>
            </View>
          ))}
        <Text style={styles.sectionTitle}>Trending</Text>
        <View style={styles.card}>
          <View style={styles.posterGreen} />
          <View>
            <Text style={styles.cardTitle}>Jujutsu Kaisen</Text>
            <Text style={styles.subText}>#1 this week</Text>
          </View>
        </View>
      </ScrollView>
    );
  }
  function DiscoverScreen() {
    if (selectedAnime) {
      return (
        <ScrollView style={styles.content}>
          <Text style={styles.header}>Anime Detail</Text>
          <View style={styles.largePoster} />
          <Text style={styles.bigTitle}>{selectedAnime.title}</Text>
          <Text style={styles.tag}>{selectedAnime.genre}</Text>
          <Text style={styles.subText}>
            ★ {selectedAnime.rating} • {selectedAnime.episodes} episodes •{" "}
            {selectedAnime.year}
          </Text>
          <Text style={styles.description}>
            This anime is recommended based on your selected genres and trending
            shows. Add it to your watchlist to track your progress.
          </Text>
          <TouchableOpacity
            style={styles.primaryButton}
            onPress={() => addToWatchlist(selectedAnime)}
          >
            <Text style={styles.buttonText}>Add to Watchlist</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.secondaryButton}
            onPress={() => setSelectedAnime(null)}
          >
            <Text style={styles.secondaryText}>Back</Text>
          </TouchableOpacity>
        </ScrollView>
      );
    }

    return (
      <ScrollView style={styles.content}>
        <Text style={styles.header}>Discover</Text>
        <View style={styles.tabRow}>
          <Text style={styles.activeMiniTab}>For You</Text>
          <Text style={styles.miniTab}>Trending</Text>
          <Text style={styles.miniTab}>New</Text>
        </View>

        {animeData.map((anime) => (
          <TouchableOpacity
            key={anime.id}
            style={styles.discoverCard}
            onPress={() => setSelectedAnime(anime)}
          >
            <View style={styles.discoverPoster} />
            <Text style={styles.bigTitle}>{anime.title}</Text>
            <Text style={styles.subText}>
              {anime.genre} • {anime.episodes} episodes • {anime.year}
            </Text>
            <Text style={styles.ratingBadge}>★ {anime.rating}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    );
  }

  function ListScreen() {
    return (
      <ScrollView style={styles.content}>
        <Text style={styles.header}>My List</Text>

        {watchlist.length === 0 ? (
          <Text style={styles.subText}>No anime added yet.</Text>
        ) : (
          watchlist.map((item) => (
            <View key={item.id} style={styles.listCard}>
              <View style={styles.poster} />
              <View style={{ flex: 1 }}>
                <Text style={styles.cardTitle}>{item.title}</Text>
                <Text style={styles.subText}>
                  {item.status} • Ep {item.progress} / {item.episodes}
                </Text>

                <View style={styles.progressBar}>
                  <View
                    style={[
                      styles.progressFill,
                      { width: `${(item.progress / item.episodes) * 100}%` },
                    ]}
                  />
                </View>

                <View style={styles.buttonRow}>
                  <TouchableOpacity
                    style={styles.smallButton}
                    onPress={() => updateProgress(item.id, -1)}
                  >
                    <Text style={styles.buttonText}>-</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.smallButton}
                    onPress={() => updateProgress(item.id, 1)}
                  >
                    <Text style={styles.buttonText}>+</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.statusButton}
                    onPress={() => updateStatus(item.id, "Completed")}
                  >
                    <Text style={styles.buttonText}>Done</Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.buttonRow}>
                  {[1, 2, 3, 4, 5].map((star) => (
                    <TouchableOpacity
                      key={star}
                      onPress={() => updateRating(item.id, star)}
                    >
                      <Text style={styles.star}>
                        {star <= item.userRating ? "★" : "☆"}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            </View>
          ))
        )}
      </ScrollView>
    );
  }

  function StatsScreen() {
    return (
      <ScrollView style={styles.content}>
        <Text style={styles.header}>Stats</Text>

        <View style={styles.statsRow}>
          <View style={styles.statBox}>
            <Text style={styles.statNumber}>{totalEpisodes}</Text>
            <Text style={styles.subText}>episodes</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={styles.statNumber}>{watchlist.length}</Text>
            <Text style={styles.subText}>series</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={styles.statNumber}>{totalHours}h</Text>
            <Text style={styles.subText}>watched</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Top Genres</Text>

        {["Action", "Fantasy", "Mystery"].map((genre) => (
          <View key={genre} style={styles.genreRow}>
            <Text style={styles.cardTitle}>{genre}</Text>
            <Text style={styles.subText}>{getGenreCount(genre)} series</Text>
          </View>
        ))}

        <Text style={styles.sectionTitle}>Completed</Text>
        {completed.length === 0 ? (
          <Text style={styles.subText}>No completed anime yet.</Text>
        ) : (
          completed.map((item) => (
            <View key={item.id} style={styles.card}>
              <View style={styles.posterOrange} />
              <View>
                <Text style={styles.cardTitle}>{item.title}</Text>
                <Text style={styles.subText}>
                  {item.episodes} episodes • Rating {item.userRating}/5
                </Text>
              </View>
            </View>
          ))
        )}
      </ScrollView>
    );
  }

  function renderScreen() {
    if (screen === "Home") return <HomeScreen />;
    if (screen === "Discover") return <DiscoverScreen />;
    if (screen === "List") return <ListScreen />;
    return <StatsScreen />;
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.phone}>
        {renderScreen()}

        <View style={styles.nav}>
          {["Home", "Discover", "List", "Stats"].map((tab) => (
            <TouchableOpacity
              key={tab}
              style={styles.navItem}
              onPress={() => {
                setScreen(tab);
                setSelectedAnime(null);
              }}
            >
              <View
                style={[
                  styles.navIcon,
                  screen === tab && styles.activeNavIcon,
                ]}
              />
              <Text
                style={[
                  styles.navText,
                  screen === tab && styles.activeNavText,
                ]}
              >
                {tab}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#121826",
    alignItems: "center",
    justifyContent: "center",
  },
  phone: {
    width: "92%",
    height: "92%",
    backgroundColor: "#1f1f1f",
    borderRadius: 25,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "#3a3a3a",
  },
  content: {
    flex: 1,
    padding: 16,
  },
  header: {
    color: "white",
    fontSize: 26,
    fontWeight: "bold",
    marginBottom: 18,
  },
  title: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },
  bigTitle: {
    color: "white",
    fontSize: 22,
    fontWeight: "bold",
    marginTop: 10,
  },
  sectionTitle: {
    color: "white",
    fontSize: 19,
    fontWeight: "bold",
    marginTop: 18,
    marginBottom: 10,
  },
  subText: {
    color: "#b7b7b7",
    fontSize: 14,
  },
  profileRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
  },
  avatar: {
    width: 45,
    height: 45,
    borderRadius: 22,
    backgroundColor: "#a89eff",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
  },
  avatarText: {
    color: "#1f1f1f",
    fontWeight: "bold",
  },
  card: {
    flexDirection: "row",
    backgroundColor: "#2a2a2a",
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    alignItems: "center",
  },
  listCard: {
    flexDirection: "row",
    backgroundColor: "#2a2a2a",
    borderRadius: 12,
    padding: 12,
    marginBottom: 14,
  },
  discoverCard: {
    backgroundColor: "#2a2a2a",
    borderRadius: 15,
    padding: 14,
    marginBottom: 15,
  },
  poster: {
    width: 55,
    height: 65,
    backgroundColor: "#a89eff",
    borderRadius: 6,
    marginRight: 12,
  },
  posterGreen: {
    width: 55,
    height: 65,
    backgroundColor: "#9ce3cf",
    borderRadius: 6,
    marginRight: 12,
  },
  posterOrange: {
    width: 55,
    height: 65,
    backgroundColor: "#ff9a7a",
    borderRadius: 6,
    marginRight: 12,
  },
  discoverPoster: {
    height: 150,
    backgroundColor: "#a89eff",
    borderRadius: 12,
    marginBottom: 8,
  },
  largePoster: {
    height: 180,
    backgroundColor: "#6252d9",
    borderRadius: 15,
  },
  cardTitle: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
  },
  progressBar: {
    height: 6,
    backgroundColor: "#555",
    borderRadius: 5,
    marginTop: 8,
    overflow: "hidden",
  },
  progressFill: {
    height: 6,
    backgroundColor: "#6252d9",
  },
  nav: {
    flexDirection: "row",
    height: 70,
    backgroundColor: "#252525",
    borderTopWidth: 1,
    borderTopColor: "#333",
  },
  navItem: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  navIcon: {
    width: 22,
    height: 22,
    backgroundColor: "#111",
    borderRadius: 5,
    marginBottom: 4,
  },
  activeNavIcon: {
    backgroundColor: "#d7d3ff",
  },
  navText: {
    color: "#777",
    fontSize: 12,
  },
  activeNavText: {
    color: "#8b7cff",
  },
  tabRow: {
    flexDirection: "row",
    marginBottom: 12,
  },
  miniTab: {
    color: "#888",
    marginRight: 25,
  },
  activeMiniTab: {
    color: "#8b7cff",
    marginRight: 25,
    fontWeight: "bold",
  },
  ratingBadge: {
    color: "white",
    backgroundColor: "#6252d9",
    padding: 6,
    borderRadius: 8,
    width: 70,
    marginTop: 8,
    textAlign: "center",
  },
  tag: {
    color: "#1f1f1f",
    backgroundColor: "#f1eec9",
    padding: 7,
    borderRadius: 12,
    width: 80,
    textAlign: "center",
    marginTop: 8,
    fontWeight: "bold",
  },
  description: {
    color: "#ddd",
    fontSize: 15,
    marginTop: 15,
    lineHeight: 22,
  },
  primaryButton: {
    backgroundColor: "#6252d9",
    padding: 14,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 20,
  },
  secondaryButton: {
    borderWidth: 1,
    borderColor: "#6252d9",
    padding: 14,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 10,
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
  },
  secondaryText: {
    color: "#8b7cff",
    fontWeight: "bold",
  },
  buttonRow: {
    flexDirection: "row",
    marginTop: 10,
    alignItems: "center",
  },
  smallButton: {
    backgroundColor: "#6252d9",
    width: 35,
    height: 30,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 8,
  },
  statusButton: {
    backgroundColor: "#6252d9",
    paddingHorizontal: 12,
    height: 30,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  star: {
    color: "#ffc94a",
    fontSize: 24,
    marginRight: 4,
  },
  statsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  statBox: {
    backgroundColor: "#2a2a2a",
    width: "31%",
    padding: 12,
    borderRadius: 12,
    alignItems: "center",
  },
  statNumber: {
    color: "white",
    fontSize: 22,
    fontWeight: "bold",
  },
  genreRow: {
    backgroundColor: "#2a2a2a",
    padding: 14,
    borderRadius: 12,
    marginBottom: 10,
  },
});